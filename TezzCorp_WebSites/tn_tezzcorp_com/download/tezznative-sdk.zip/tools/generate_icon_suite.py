#!/usr/bin/env python3
"""
generate_icon_suite.py — Generate complete TezzNative brand icons & favicon suite.
Uses the new 3D .tn logo on a sleek high-tech dark disc/squircle backdrop so it has
100% contrast and visibility on both day (light) and dark browser tabs & OS themes.
"""

import os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

def make_styled_tile(emblem: Image.Image, size: int = 512, corner_radius: float = 0.22) -> Image.Image:
    """Renders the emblem onto a deep midnight navy rounded squircle tile with subtle cyan border."""
    tile = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(tile)
    
    # Base dark gradient simulation using multiple rounded rectangles
    r = int(size * corner_radius)
    margin = int(size * 0.02)
    box = [margin, margin, size - margin, size - margin]
    
    # Background: deep midnight navy #070d1e
    draw.rounded_rectangle(box, radius=r, fill=(7, 13, 30, 255), outline=(14, 165, 233, 220), width=max(1, int(size * 0.025)))
    
    # Inner subtle glow ring
    inner_margin = margin + max(1, int(size * 0.02))
    inner_box = [inner_margin, inner_margin, size - inner_margin, size - inner_margin]
    draw.rounded_rectangle(inner_box, radius=max(1, r - 4), fill=None, outline=(56, 189, 248, 90), width=max(1, int(size * 0.012)))

    # Fit emblem inside tile (78% of tile size)
    cw, ch = emblem.size
    scale = (size * 0.76) / max(cw, ch)
    ew = int(cw * scale)
    eh = int(ch * scale)
    resized_emblem = emblem.resize((ew, eh), Image.Resampling.LANCZOS)
    
    paste_x = (size - ew) // 2
    paste_y = (size - eh) // 2
    tile.alpha_composite(resized_emblem, (paste_x, paste_y))
    return tile

def generate_icons(src_image_path: str, repo_root: Path):
    im = Image.open(src_image_path).convert("RGBA")
    bbox = im.getbbox()
    cropped = im.crop(bbox)
    cw, ch = cropped.size
    print(f"[IconGen] Extracted emblem bounding box: {cw}x{ch}")

    # 1. Master transparent logo (for website header, banner, about page)
    max_dim = max(cw, ch)
    target_dim = int(max_dim * 1.15)
    square_im = Image.new("RGBA", (target_dim, target_dim), (0, 0, 0, 0))
    paste_x = (target_dim - cw) // 2
    paste_y = (target_dim - ch) // 2
    square_im.paste(cropped, (paste_x, paste_y), cropped)

    im1024_transparent = square_im.resize((1024, 1024), Image.Resampling.LANCZOS)

    dest_logos = [
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "assets" / "logo.png",
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "assets" / "logo" / "tezz-logo.png",
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "assets" / "logo" / "tezz-corp-logo.png",
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "assets" / "tezz-corp-logo.png",
        repo_root / "tezz-corp-logo.png",
        repo_root / "TezzNative-language" / "tezz-corp-logo.png",
        repo_root / "tezznative-vscode" / "tezzcorp-logo.png",
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "download" / "sdk" / "tezznative-vscode" / "tezzcorp-logo.png",
    ]
    for p in dest_logos:
        p.parent.mkdir(parents=True, exist_ok=True)
        im1024_transparent.save(str(p), "PNG")
        print(f"  [OK] Saved transparent brand logo: {p}")

    # 2. Master styled tile for Favicons (visible in ALL light and dark tabs)
    tile512 = make_styled_tile(cropped, 512)
    tile192 = tile512.resize((192, 192), Image.Resampling.LANCZOS)
    tile180 = tile512.resize((180, 180), Image.Resampling.LANCZOS)
    tile64  = tile512.resize((64, 64), Image.Resampling.LANCZOS)
    tile48  = tile512.resize((48, 48), Image.Resampling.LANCZOS)
    tile32  = tile512.resize((32, 32), Image.Resampling.LANCZOS)
    tile16  = tile512.resize((16, 16), Image.Resampling.LANCZOS)

    fav_dirs = [
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "assets" / "favicon",
        repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "favicon",
    ]

    for fdir in fav_dirs:
        fdir.mkdir(parents=True, exist_ok=True)
        tile512.save(str(fdir / "android-chrome-512x512.png"), "PNG")
        tile192.save(str(fdir / "android-chrome-192x192.png"), "PNG")
        tile180.save(str(fdir / "apple-touch-icon.png"), "PNG")
        tile32.save(str(fdir / "favicon-32x32.png"), "PNG")
        tile16.save(str(fdir / "favicon-16x16.png"), "PNG")
        tile512.save(str(fdir / "favicon.ico"), format="ICO", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64)])
        print(f"  [OK] Saved favicon suite in: {fdir}")

    # Root website favicon.ico
    tile512.save(str(repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com" / "favicon.ico"), format="ICO", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64)])

    # 3. Create SVG favicon with embedded high-res tile base64
    import base64
    import io
    b = io.BytesIO()
    tile512.save(b, format="PNG")
    b64_data = base64.b64encode(b.getvalue()).decode("ascii")
    svg_content = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <image href="data:image/png;base64,{b64_data}" width="512" height="512"/>
</svg>'''
    for fdir in fav_dirs:
        (fdir / "icon.svg").write_text(svg_content, encoding="utf-8")
        print(f"  [OK] Saved SVG icon: {fdir / 'icon.svg'}")

    # 4. Update manifest.webmanifest and site.webmanifest
    manifest_content = '''{
  "name": "TezzNative Programming Language",
  "short_name": "TezzNative",
  "description": "Ultra-fast systems and AI programming language by TEZZCORP PRIVATE LIMITED",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#070d1e",
  "theme_color": "#0ea5e9",
  "icons": [
    {
      "src": "/favicon/android-chrome-192x192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/favicon/android-chrome-512x512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}'''
    for fdir in fav_dirs:
        (fdir / "site.webmanifest").write_text(manifest_content, encoding="utf-8")
        (fdir / "manifest.webmanifest").write_text(manifest_content, encoding="utf-8")

    # 5. Windows Application Icons (.ico with full mipmaps 16..256)
    ico_destinations = [
        repo_root / "TezzNative-language" / "assets" / "tezz.ico",
        repo_root / "TezzNative-language" / "assets" / "calculator.ico",
        repo_root / "TezzNative-language" / "assets" / "calculator_blue.ico",
    ]
    for ipath in ico_destinations:
        ipath.parent.mkdir(parents=True, exist_ok=True)
        tile512.save(str(ipath), format="ICO", sizes=[(16,16), (24,24), (32,32), (48,48), (64,64), (128,128), (256,256)])
        print(f"  [OK] Saved Windows .ico: {ipath}")

    print("[IconGen] Complete icon & favicon suite generated successfully!")

if __name__ == "__main__":
    src = r"C:/Users/aryaa/.gemini/antigravity/brain/b62d80ab-e5e7-494f-8580-4242c28fbf9a/.user_uploaded/media_1794460999084_b9242208.png"
    root = Path(r"C:\Acer\Code\TezzNative")
    generate_icons(src, root)
