# tools/serve_portal.ps1 — Launch local development web server for tezznative.org
Param(
  [int]$Port = 8000
)

$siteDir = Join-Path $PSScriptRoot "..\TezzCorp_WebSites\tn_tezzcorp_com"
if (-not (Test-Path $siteDir)) {
  Write-Error "Site directory not found: $siteDir"
  exit 1
}

$siteResolved = (Resolve-Path $siteDir).Path
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " Starting TezzNative Official Portal Local Dev Server     " -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host " Site Root: $siteResolved" -ForegroundColor Gray
Write-Host " URL:       http://localhost:$Port" -ForegroundColor Yellow
Write-Host " Press Ctrl+C to stop the server.`n" -ForegroundColor Gray

Set-Location $siteResolved
& php -S "localhost:$Port"

