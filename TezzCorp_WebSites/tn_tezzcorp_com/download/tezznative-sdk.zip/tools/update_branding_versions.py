#!/usr/bin/env python3
"""
update_branding_versions.py — Update company name to TEZZCORP PRIVATE LIMITED,
standardize version to v1.0.0, and fix footer copyright duplication.
"""

from pathlib import Path

repo_root = Path(r"C:\Acer\Code\TezzNative")
web_root = repo_root / "TezzCorp_WebSites" / "tn_tezzcorp_com"

# 1. Update i18n.php
i18n_path = web_root / "includes" / "i18n.php"
if i18n_path.exists():
    content = i18n_path.read_text(encoding="utf-8")
    
    # Remove duplicated company prefix in footer_copyright
    content = content.replace("'footer_copyright' => 'TezzCorp Pvt Ltd. — ", "'footer_copyright' => '")
    content = content.replace("'footer_copyright' => 'तेजकॉर्प प्राइवेट लिमिटेड — ", "'footer_copyright' => '")
    
    # Update operational status versions
    content = content.replace("TezzNative v2.2.1 Production Operational", "TezzNative v1.0.0 Production Operational")
    content = content.replace("TezzNative v2.2.1", "TezzNative v1.0.0")
    content = content.replace("v2.2.1", "v1.0.0")
    content = content.replace("TezzNative v2.2", "TezzNative v1.0.0")
    content = content.replace("v2.2", "v1.0.0")
    
    # Update company name to TEZZCORP PRIVATE LIMITED
    content = content.replace("TezzCorp Pvt Ltd.", "TEZZCORP PRIVATE LIMITED")
    content = content.replace("TezzCorp Pvt Ltd", "TEZZCORP PRIVATE LIMITED")
    content = content.replace("TEZZCORP PVT LTD", "TEZZCORP PRIVATE LIMITED")
    
    i18n_path.write_text(content, encoding="utf-8")
    print(f"[OK] Updated {i18n_path}")

# 2. Update index.php
index_path = web_root / "index.php"
if index_path.exists():
    c = index_path.read_text(encoding="utf-8")
    c = c.replace("TezzCorp Pvt Ltd.", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("TezzCorp Pvt Ltd", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("TEZZCORP PVT LTD", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("v2.2.1", "v1.0.0")
    c = c.replace("v1.1.0", "v1.0.0")
    index_path.write_text(c, encoding="utf-8")
    print(f"[OK] Updated {index_path}")

# 3. Update community.php
comm_path = web_root / "community.php"
if comm_path.exists():
    c = comm_path.read_text(encoding="utf-8")
    c = c.replace("TezzCorp Pvt Ltd.", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("TezzCorp Pvt Ltd", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("TEZZCORP PVT LTD", "TEZZCORP PRIVATE LIMITED")
    c = c.replace("v2.2.1", "v1.0.0")
    c = c.replace("v1.1.0", "v1.0.0")
    comm_path.write_text(c, encoding="utf-8")
    print(f"[OK] Updated {comm_path}")

# 4. Update about.php, contact.php, privacy.php, terms.php, news.php
for fname in ["about.php", "contact.php", "privacy.php", "terms.php", "news.php"]:
    p = web_root / fname
    if p.exists():
        c = p.read_text(encoding="utf-8")
        c = c.replace("TezzCorp Pvt Ltd.", "TEZZCORP PRIVATE LIMITED")
        c = c.replace("TezzCorp Pvt Ltd", "TEZZCORP PRIVATE LIMITED")
        c = c.replace("TEZZCORP PVT LTD", "TEZZCORP PRIVATE LIMITED")
        c = c.replace("v2.2.1", "v1.0.0")
        c = c.replace("v1.1.0", "v1.0.0")
        p.write_text(c, encoding="utf-8")
        print(f"[OK] Updated {p}")

print("Branding and version update completed!")
