import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from ssh_helper import run_remote

check_script = """php -r '
try {
    $pdo = new PDO("mysql:host=localhost;dbname=u190073748_tezz_official_;charset=utf8mb4", "u190073748_tezz_usr__vr__", "TezzCorpOfficial#@2026", [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
    foreach (["tn_package_registry", "tezz_package_registry"] as $table) {
        echo "=== SCHEMA: $table ===\\n";
        $stmt = $pdo->query("DESCRIBE $table");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "  {$row[\"Field\"]} | {$row[\"Type\"]} | {$row[\"Null\"]} | {$row[\"Default\"]}\\n";
        }
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "  COUNT: $count\\n\\n";
    }
} catch (Exception $e) {
    echo "DB_ERROR: " . $e->getMessage() . "\\n";
}
'"""

out, err = run_remote(check_script)
print("OUTPUT:\n", out)
if err:
    print("ERROR:\n", err)
