#!/usr/bin/env python3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from ssh_helper import get_sftp

LOCAL_ROOT = Path(r"C:\Acer\Code\TezzNative\TezzCorp_WebSites\tn_tezzcorp_com")
PRIMARY_TARGET = "/home/u190073748/domains/tezznative.org/public_html"
LEGACY_TARGET = "/home/u190073748/domains/tezzcorp.com/public_html/tn.tezzcorp.com"

# Exact list of modified and relevant files to sync
FILES_TO_SYNC = [
    "about.php",
    "frameworks.php",
    "frameworks/_framework_page.php",
    "terms.php",
    "privacy.php",
    "install.ps1",
    "install.sh",
    "includes/nav.php",
    "includes/footer.php",
    "docs/index.php",
    "docs/language.php",
    "docs/actor-runtime.php",
    "docs/backend.php",
    "docs/benchmarks.php",
    "docs/c-abi.php",
    "docs/conformance.php",
    "docs/developer-experience.php",
    "docs/examples.php",
    "docs/native-backend.php",
    "docs/optimization-plan.php",
    "docs/package-trust.php",
    "docs/python-bridge.php",
    "docs/sdk.php",
    "docs/stability.php",
    "docs/stdlib-core.php",
    "docs/tezzdb.php",
    "docs/trust-baseline.php",
    "download/release_manifest.json",
    "download/release_manifest.json.sha256",
    "download/tezznative-sdk.zip",
    "download/tezznative-sdk.zip.sha256",
    "download/tezznative-sdk-linux.tar.gz",
    "download/tezznative-sdk-linux.tar.gz.sha256",
    "download/sdk/tools/tezz.tn",
    "download/sdk/hello.tn",
]

PURGE_LIST = [
    "header.php",
    "footer.php",
    "frameworks/_fw_template.php",
    "api/v2/admission.php",
    "api/v2/progression-manage.php",
    "api/v2/progression.php",
    "api/v2/students-manage.php",
]

def ensure_remote_dir(sftp, remote_dir):
    parts = remote_dir.strip("/").split("/")
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            sftp.stat(cur)
        except IOError:
            try:
                sftp.mkdir(cur)
            except IOError:
                pass

def main():
    print("[1] Connecting to server via SFTP...", flush=True)
    ssh, sftp = get_sftp()
    print("Connected successfully!", flush=True)

    targets = [PRIMARY_TARGET, LEGACY_TARGET]

    for target in targets:
        print(f"\n--- Syncing to {target} ---", flush=True)
        # Purge deleted files
        for p in PURGE_LIST:
            rf = f"{target}/{p}"
            try:
                sftp.remove(rf)
                print(f"  [PURGED] {p}", flush=True)
            except Exception:
                pass

        # Upload files
        for rel in FILES_TO_SYNC:
            local_fp = LOCAL_ROOT / rel
            if not local_fp.exists():
                print(f"  [SKIP] Not found locally: {rel}", flush=True)
                continue
            remote_fp = f"{target}/{rel.replace('\\', '/')}"
            remote_dir = remote_fp.rsplit("/", 1)[0]
            ensure_remote_dir(sftp, remote_dir)

            try:
                sftp.put(str(local_fp), remote_fp)
                sz = local_fp.stat().st_size
                print(f"  [UPLOADED] {rel} ({sz} bytes)", flush=True)
            except Exception as e:
                print(f"  [ERROR] {rel}: {e}", flush=True)

    sftp.close()
    ssh.close()
    print("\n[DONE] All updates deployed successfully to live servers!", flush=True)

if __name__ == "__main__":
    main()
